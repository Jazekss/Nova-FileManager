Build "Nova File Manager", an Android file manager in Flutter (Dart), for
personal use and possibly later Google Play. Use skills: flutter-standards,
flutter-platforms, project-memory, debug-discipline. Keep PROJECT_MAP.md
updated after every phase. Reply to me in Latvian.
Test on the Android Studio emulator (flutter run). Android only for now.

PHASE 1 (core):
- Home screen: card at top with storage stats (used/free for internal storage
  and SD card side by side, installed app count if feasible).
- Bottom navigation: Home, File Manager, Search.
- File Manager: browse internal storage and SD card; switch storage inside the
  manager. Views: detailed list (name, size, created/modified date+time), small
  icons, large icons (name, date, size; time only in detailed view and in the
  long-press context menu "Properties").
- Per-folder toolbar: new folder, multi-select; actions copy, move, delete,
  rename. Move/copy between folders and storages.
- Settings: units MB/KB, theme (light/dark/system), show hidden files.
- Search: choose storage, folders, date range (from-to), text; support
  Windows-style wildcards (e.g. *.pdf).

PHASE 2:
- Own recycle bin (app folder + metadata): restore, delete, move; size on home.
- Archives: create ZIP, read ZIP/7z/RAR (RAR read-only).
- Open media with system apps; built-in image viewer; small built-in audio and
  video player (fullscreen, swipe seek) ONLY if it does not make the app much larger.

PHASE 3:
- Google Drive sign-in (smallest OAuth scope that works), browse and move files.
- Vault: private encrypted storage in the app, PIN/biometrics unlock
  (AES-GCM, key in Android Keystore).
- Image format conversion (PNG/JPG/WebP).

Notes: handle All-files-access and SD card (SAF) permissions properly; explain
limits (Android/data, no true system files without root) in the UI.
Run `flutter analyze` and `flutter test` and tell me exactly what you ran.
Start with Phase 1 only and stop for my review.
