# Nova File Manager - project map

Android file manager (Flutter). Keep this file under ~150 lines.

## Status
- Phase 1: not started
- Phase 2: not started
- Phase 3: not started

## Modules
(one line per module: purpose and main files)

## Decisions
(short list of key choices)
